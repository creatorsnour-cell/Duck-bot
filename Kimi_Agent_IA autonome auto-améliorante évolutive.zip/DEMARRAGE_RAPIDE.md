# 🚀 Démarrage Rapide - Nouria AI

---

## ✅ En 3 Secondes

**🔗 Ouvrez : https://tdjolco452gms.ok.kimi.link**

C'est tout ! Nouria est prête à discuter.

---

## 💬 Essayez Ces Messages

### Pour Tester Nouria :

```
Salut Nouria !
```

```
Qui es-tu ?
```

```
Raconte-moi une blague
```

```
Crée une application React
```

```
Donne-moi des idées de projets
```

---

## 🎯 Actions Rapides

Cliquez sur les boutons dans l'interface :

| Bouton | Ce que ça fait |
|--------|----------------|
| **Créer une app React** | Génère une app React complète |
| **Site web portfolio** | Crée un portfolio HTML/CSS |
| **Script Python** | Écrit un script Python |
| **Générer une image** | Lance le mode création d'image |

---

## ⌨️ Raccourcis

| Touche | Action |
|--------|--------|
| `/` | Met le curseur dans le chat |
| `Entrée` | Envoie le message |

---

## 🛠️ Pour Aller Plus Loin

### Voir la Documentation Complète :
- 📖 `NOURIA_GUIDE.md` - Guide utilisateur complet
- 🎨 `PRESENTATION_NOURIA.md` - Présentation détaillée
- 💻 `README.md` - Documentation technique

### Connecter des API (Optionnel) :
1. Ouvrez `app/src/config/api-config.ts`
2. Ajoutez votre clé API OpenAI
3. Rebuild et redéployez

---

## 🆘 Besoin d'Aide ?

Nouria comprend ces demandes :
- `"Aide-moi"`
- `"Je ne comprends pas"`
- `"Explique-moi"`

---

**✨ Amusez-vous avec Nouria !**
