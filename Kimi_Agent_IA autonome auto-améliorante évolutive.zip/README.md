# 🌟 NOURIA AI - Assistant Personnel Ultime

![Nouria Avatar](./app/public/nouria-avatar.jpg)

---

## 🔗 Accès Immédiat

**🌐 https://tdjolco452gms.ok.kimi.link**

---

## ✨ Présentation

**Nouria** est votre assistant IA personnel ultra-performant, conçu pour répondre à absolument toutes vos demandes. Avec son interface futuriste et ses capacités avancées, Nouria est prête à devenir votre compagne digitale indispensable.

### 🎯 Capacités Principales

- 💬 **Chat Intelligent** - Conversations naturelles et contextuelles
- 💻 **Génération de Code** - Crée des applications, sites web, scripts
- 🎨 **Mode Créatif** - Génération d'images et idées innovantes
- 🎤 **Support Vocal** - Dictée et réponses vocales
- ⚡ **Ultra-Rapide** - Réponses instantanées

---

## 🚀 Démarrage Rapide

### Utiliser Nouria Immédiatement

1. **Ouvrez l'URL** : https://tdjolco452gms.ok.kimi.link
2. **Commencez à discuter** - Cliquez sur une action rapide ou tapez votre message
3. **Explorez** - Testez toutes les fonctionnalités !

### Raccourcis Clavier

| Touche | Action |
|--------|--------|
| `/` | Focus sur la zone de saisie |
| `Entrée` | Envoyer le message |
| `Maj + Entrée` | Nouvelle ligne |

---

## 📁 Structure du Projet

```
/mnt/okcomputer/output/
│
├── 📄 PRESENTATION_NOURIA.md      # Présentation complète
├── 📄 NOURIA_GUIDE.md             # Guide utilisateur détaillé
├── 📄 README.md                   # Ce fichier
│
└── 📁 app/                        # Application React
    ├── 📁 src/
    │   ├── 📄 App.tsx             # Composant principal
    │   ├── 📄 index.css           # Styles globaux
    │   │
    │   ├── 📁 lib/
    │   │   └── 📄 nouria-responses.ts  # 🧠 Système de réponses IA
    │   │
    │   ├── 📁 config/
    │   │   └── 📄 api-config.ts   # ⚙️ Configuration API
    │   │
    │   └── 📁 components/ui/      # 🎨 Composants UI (shadcn)
    │
    ├── 📁 public/
    │   └── 🖼️ nouria-avatar.jpg   # Avatar de Nouria
    │
    └── 📁 dist/                   # 🚀 Build de production
```

---

## 🛠️ Développement

### Prérequis

- Node.js 18+
- npm ou yarn

### Installation

```bash
cd /mnt/okcomputer/output/app
npm install
```

### Lancer en mode développement

```bash
npm run dev
```

L'application sera accessible sur http://localhost:5173

### Build pour production

```bash
npm run build
```

Le build sera généré dans le dossier `dist/`.

---

## 🔌 Connecter des API Externes

Nouria fonctionne actuellement en mode "démo" avec un système de réponses intelligent basé sur des templates. Pour la rendre encore plus puissante, vous pouvez connecter des API externes :

### 1. OpenAI (GPT-4)

Éditez `src/config/api-config.ts` :

```typescript
export const activeConfig: ApiConfig = {
  openai: {
    enabled: true,
    apiKey: 'sk-votre-cle-api-openai',
    model: 'gpt-4-turbo',
    temperature: 0.7,
    maxTokens: 2000,
  },
};
```

### 2. Anthropic (Claude)

```typescript
anthropic: {
  enabled: true,
  apiKey: 'votre-cle-api-anthropic',
  model: 'claude-3-sonnet',
  temperature: 0.7,
  maxTokens: 2000,
},
```

### 3. Génération d'Images (DALL-E)

```typescript
imageGeneration: {
  enabled: true,
  provider: 'openai',
  apiKey: 'sk-votre-cle-api',
  defaultSize: '1024x1024',
},
```

### 4. Text-to-Speech (ElevenLabs)

```typescript
tts: {
  enabled: true,
  provider: 'elevenlabs',
  apiKey: 'votre-cle-api-elevenlabs',
  voice: 'nova',
},
```

---

## 🎨 Personnalisation

### Changer l'Avatar

Remplacez le fichier `public/nouria-avatar.jpg` par votre propre image.

### Modifier les Couleurs

Éditez `src/index.css` et modifiez les variables CSS :

```css
:root {
  --primary: 263 70% 55%;  /* Violet par défaut */
  --accent: 330 70% 55%;   /* Rose */
}
```

### Ajouter des Réponses

Éditez `src/lib/nouria-responses.ts` et ajoutez de nouveaux templates :

```typescript
{
  keywords: ['votre', 'mot-clé'],
  responses: [
    'Votre réponse personnalisée ici !',
  ],
}
```

---

## 🌟 Fonctionnalités Avancées

### Système de Réponses Intelligent

Nouria utilise un système de matching par mots-clés qui :
- Détecte l'intention de l'utilisateur
- Sélectionne la meilleure réponse
- Génère du code si nécessaire
- Propose des actions contextuelles

### Génération de Code Automatique

Nouria peut générer :
- ✅ Applications React complètes
- ✅ Composants TypeScript
- ✅ Scripts Python
- ✅ Sites HTML/CSS
- ✅ Fonctions JavaScript

### Mode Créatif

Activez le mode créatif pour :
- 🎨 Des réponses plus imaginatives
- 💡 Plus d'idées innovantes
- 🌈 Un ton plus expressif

---

## 📚 Documentation

- **Guide Utilisateur** : `NOURIA_GUIDE.md`
- **Présentation** : `PRESENTATION_NOURIA.md`
- **Configuration API** : `app/src/config/api-config.ts`
- **Système de Réponses** : `app/src/lib/nouria-responses.ts`

---

## 🚀 Déploiement

### Déploiement Actuel

Nouria est déployée sur : **https://tdjolco452gms.ok.kimi.link**

### Redéployer

```bash
cd /mnt/okcomputer/output/app
npm run build
# Puis déployez le dossier dist/
```

---

## 🔮 Roadmap

### Prochaines Fonctionnalités

- [ ] Intégration API OpenAI/Claude
- [ ] Génération d'images réelle
- [ ] Mode vocal complet
- [ ] Historique persistant
- [ ] Application mobile
- [ ] Plugins personnalisables
- [ ] Multi-langues
- [ ] Authentification utilisateur

---

## 💜 Remerciements

Nouria a été créée avec :
- ⚛️ React 18
- 🔷 TypeScript
- ⚡ Vite
- 🎨 Tailwind CSS
- 🧩 shadcn/ui
- 💻 Kimi AI

---

## 📝 License

MIT - Libre d'utilisation et de modification

---

**🌟 Votre imagination est la seule limite !**

*Développée avec 💜 - Mars 2025*
