// Configuration API pour Nouria AI
// Décommentez et configurez pour connecter Nouria à des API externes

export interface ApiConfig {
  // OpenAI Configuration
  openai?: {
    enabled: boolean;
    apiKey: string;
    model: 'gpt-4' | 'gpt-4-turbo' | 'gpt-3.5-turbo';
    temperature: number;
    maxTokens: number;
  };
  
  // Anthropic Claude Configuration
  anthropic?: {
    enabled: boolean;
    apiKey: string;
    model: 'claude-3-opus' | 'claude-3-sonnet' | 'claude-3-haiku';
    temperature: number;
    maxTokens: number;
  };
  
  // Image Generation (DALL-E, Midjourney, etc.)
  imageGeneration?: {
    enabled: boolean;
    provider: 'openai' | 'stability' | 'midjourney';
    apiKey: string;
    defaultSize: '1024x1024' | '512x512' | '256x256';
  };
  
  // Speech-to-Text
  stt?: {
    enabled: boolean;
    provider: 'openai' | 'google' | 'azure';
    apiKey: string;
  };
  
  // Text-to-Speech
  tts?: {
    enabled: boolean;
    provider: 'openai' | 'google' | 'azure' | 'elevenlabs';
    apiKey: string;
    voice: string;
  };
}

// Configuration par défaut (mode démo - sans API)
export const defaultConfig: ApiConfig = {
  openai: {
    enabled: false,
    apiKey: '',
    model: 'gpt-4-turbo',
    temperature: 0.7,
    maxTokens: 2000,
  },
  anthropic: {
    enabled: false,
    apiKey: '',
    model: 'claude-3-sonnet',
    temperature: 0.7,
    maxTokens: 2000,
  },
  imageGeneration: {
    enabled: false,
    provider: 'openai',
    apiKey: '',
    defaultSize: '1024x1024',
  },
  stt: {
    enabled: false,
    provider: 'openai',
    apiKey: '',
  },
  tts: {
    enabled: false,
    provider: 'elevenlabs',
    apiKey: '',
    voice: 'nova',
  },
};

// Configuration active (modifier cette variable)
export const activeConfig: ApiConfig = {
  ...defaultConfig,
};

// Fonction pour vérifier si une API est configurée
export function isApiConfigured(apiName: keyof ApiConfig): boolean {
  const config = activeConfig[apiName];
  return config?.enabled === true && 
         'apiKey' in config && 
         config.apiKey.length > 0;
}

// Fonction pour activer une API
export function enableApi(apiName: keyof ApiConfig, apiKey: string): void {
  if (activeConfig[apiName]) {
    activeConfig[apiName]!.enabled = true;
    activeConfig[apiName]!.apiKey = apiKey;
  }
}

// Instructions de configuration
export const setupInstructions = `
# Configuration des API pour Nouria

## 1. OpenAI (Chat GPT-4)
1. Allez sur https://platform.openai.com
2. Créez un compte ou connectez-vous
3. Générez une clé API dans "API Keys"
4. Copiez la clé et collez-la ci-dessous

## 2. Anthropic (Claude)
1. Allez sur https://console.anthropic.com
2. Créez un compte
3. Obtenez une clé API
4. Configurez dans ce fichier

## 3. Génération d'Images (DALL-E)
1. Utilisez votre clé OpenAI
2. Activez l'option imageGeneration
3. Nouria pourra générer des images

## 4. Text-to-Speech (ElevenLabs)
1. Allez sur https://elevenlabs.io
2. Créez un compte gratuit
3. Obtenez votre clé API
4. Configurez dans la section tts

## Exemple de configuration :

export const activeConfig: ApiConfig = {
  openai: {
    enabled: true,
    apiKey: 'sk-votre-cle-api-ici',
    model: 'gpt-4-turbo',
    temperature: 0.7,
    maxTokens: 2000,
  },
  // ... autres configurations
};
`;

export default activeConfig;
