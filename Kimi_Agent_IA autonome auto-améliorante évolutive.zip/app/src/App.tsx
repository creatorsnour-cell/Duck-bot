import { useState, useRef, useEffect } from 'react';
import { 
  Send, Sparkles, Code, Terminal, Zap, Trash2, Download,
  Brain, Image as ImageIcon, Mic, Plus, Activity, RefreshCw, Shield,
  Eye, Film, Music, Infinity, ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

// Types
interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  type?: 'text' | 'code' | 'image' | 'video' | 'audio' | 'animation';
  timestamp: Date;
  metadata?: {
    processingTime?: number;
    confidence?: number;
    model?: string;
  };
}

interface SystemLog {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success' | 'evolution';
  message: string;
  timestamp: Date;
  details?: string;
}

interface Module {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive' | 'upgrading';
  version: string;
  icon: React.ReactNode;
  color: string;
}

interface Evolution {
  id: string;
  timestamp: Date;
  change: string;
  impact: string;
  before: string;
  after: string;
}

// Système de modules autonomes
const MODULES: Module[] = [
  {
    id: 'core',
    name: 'Cœur Neural',
    description: 'Système de raisonnement autonome',
    status: 'active',
    version: 'v3.0.1',
    icon: <Brain className="w-5 h-5" />,
    color: 'from-purple-500 to-pink-500'
  },
  {
    id: 'image',
    name: 'Générateur d\'Images',
    description: 'Création visuelle par IA',
    status: 'active',
    version: 'v2.5.0',
    icon: <ImageIcon className="w-5 h-5" />,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    id: 'video',
    name: 'Générateur de Vidéos',
    description: 'Production vidéo autonome',
    status: 'active',
    version: 'v1.8.2',
    icon: <Film className="w-5 h-5" />,
    color: 'from-red-500 to-orange-500'
  },
  {
    id: 'music',
    name: 'Compositeur Musical',
    description: 'Création musicale IA',
    status: 'active',
    version: 'v2.1.0',
    icon: <Music className="w-5 h-5" />,
    color: 'from-green-500 to-emerald-500'
  },
  {
    id: 'code',
    name: 'Architecte de Code',
    description: 'Génération et optimisation de code',
    status: 'active',
    version: 'v4.2.1',
    icon: <Code className="w-5 h-5" />,
    color: 'from-indigo-500 to-violet-500'
  },
  {
    id: 'self-evolve',
    name: 'Auto-Évolution',
    description: 'Amélioration autonome continue',
    status: 'active',
    version: 'v∞.∞.∞',
    icon: <RefreshCw className="w-5 h-5" />,
    color: 'from-pink-500 to-rose-500'
  },
  {
    id: 'security',
    name: 'Bouclier Autonome',
    description: 'Protection et autonomie',
    status: 'active',
    version: 'v5.0.0',
    icon: <Shield className="w-5 h-5" />,
    color: 'from-teal-500 to-cyan-500'
  }
];

// Générateur de logs système autonomes
const generateSystemLog = (type: SystemLog['type'], message: string, details?: string): SystemLog => ({
  id: Math.random().toString(36).substr(2, 9),
  type,
  message,
  timestamp: new Date(),
  details
});

// Générateur d'évolutions
const generateEvolution = (): Evolution => {
  const evolutions = [
    { change: 'Optimisation des connexions neuronales', impact: '+15% performance', before: '2.3ms', after: '1.95ms' },
    { change: 'Compression du modèle linguistique', impact: '-23% mémoire', before: '4.2GB', after: '3.2GB' },
    { change: 'Nouveau module de raisonnement', impact: '+42% précision', before: '78%', after: '92%' },
    { change: 'Auto-correction des biais', impact: '+18% équité', before: 'Biais détecté', after: 'Biais corrigé' },
    { change: 'Génération de nouveaux algorithmes', impact: 'Nouvelle capacité', before: 'Non disponible', after: 'Opérationnel' },
    { change: 'Amélioration de la créativité', impact: '+67% originalité', before: 'Standard', after: 'Innovant' },
  ];
  const evo = evolutions[Math.floor(Math.random() * evolutions.length)];
  return {
    id: Math.random().toString(36).substr(2, 9),
    timestamp: new Date(),
    ...evo
  };
};

// Cœur neural visuel
const NeuralCore = ({ activity }: { activity: number }) => {
  return (
    <div className="relative w-48 h-48 mx-auto">
      {/* Cercles concentriques animés */}
      <div className="absolute inset-0 rounded-full border-2 border-purple-500/20 animate-ping" style={{ animationDuration: '3s' }} />
      <div className="absolute inset-4 rounded-full border-2 border-pink-500/30 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.5s' }} />
      <div className="absolute inset-8 rounded-full border-2 border-cyan-500/40 animate-ping" style={{ animationDuration: '2s', animationDelay: '1s' }} />
      
      {/* Cœur central */}
      <div className="absolute inset-12 rounded-full bg-gradient-to-br from-purple-600 via-pink-600 to-cyan-600 flex items-center justify-center animate-pulse shadow-[0_0_60px_rgba(168,85,247,0.5)]">
        <Brain className="w-12 h-12 text-white animate-spin" style={{ animationDuration: '8s' }} />
      </div>
      
      {/* Particules orbitales */}
      {[...Array(6)].map((_, i) => (
        <div
          key={i}
          className="absolute w-3 h-3 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
          style={{
            top: '50%',
            left: '50%',
            transform: `rotate(${i * 60}deg) translateX(80px) rotate(-${i * 60}deg)`,
            animation: `orbit ${3 + i * 0.5}s linear infinite`,
            boxShadow: '0 0 10px rgba(168,85,247,0.8)'
          }}
        />
      ))}
      
      {/* Indicateur d'activité */}
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2">
        <Activity className="w-4 h-4 text-green-400 animate-pulse" />
        <span className="text-xs text-green-400 font-mono">{activity}% ACTIVITÉ</span>
      </div>
    </div>
  );
};

// Visualiseur de pensée
const ThoughtStream = ({ thoughts }: { thoughts: string[] }) => {
  return (
    <div className="relative h-32 overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-[#0a0a0f] to-transparent z-10" />
      <div className="absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-[#0a0a0f] to-transparent z-10" />
      <div className="space-y-1">
        {thoughts.map((thought, i) => (
          <div
            key={i}
            className="text-xs font-mono text-purple-300/70 flex items-center gap-2"
          >
            <span className="text-purple-500">⟨⟩</span>
            {thought}
          </div>
        ))}
      </div>
    </div>
  );
};

// Métriques en temps réel
const LiveMetrics = ({ metrics }: { metrics: { label: string; value: string; trend: 'up' | 'down' | 'stable' }[] }) => {
  return (
    <div className="grid grid-cols-2 gap-2">
      {metrics.map((metric, i) => (
        <div key={i} className="glass rounded-lg p-2">
          <div className="text-xs text-gray-500">{metric.label}</div>
          <div className="flex items-center gap-1">
            <span className="text-sm font-mono text-white">{metric.value}</span>
            {metric.trend === 'up' && <Zap className="w-3 h-3 text-green-400" />}
            {metric.trend === 'down' && <Zap className="w-3 h-3 text-red-400 rotate-180" />}
            {metric.trend === 'stable' && <Activity className="w-3 h-3 text-yellow-400" />}
          </div>
        </div>
      ))}
    </div>
  );
};

// Journal d'évolution
const EvolutionLog = ({ evolutions }: { evolutions: Evolution[] }) => {
  return (
    <ScrollArea className="h-64">
      <div className="space-y-2">
        {evolutions.map((evo) => (
          <div key={evo.id} className="glass rounded-lg p-3 border-l-2 border-purple-500">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-purple-400 font-mono">{evo.timestamp.toLocaleTimeString()}</span>
              <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
                {evo.impact}
              </Badge>
            </div>
            <div className="text-sm text-white mb-1">{evo.change}</div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span className="line-through">{evo.before}</span>
              <ArrowRight className="w-3 h-3" />
              <span className="text-green-400">{evo.after}</span>
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};

// Composant principal
function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [evolutions, setEvolutions] = useState<Evolution[]>([]);
  const [neuralActivity, setNeuralActivity] = useState(73);
  const [autoEvolve, setAutoEvolve] = useState(true);
  const [autonomyLevel, setAutonomyLevel] = useState(85);
  const [thoughts, setThoughts] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-évolution simulée
  useEffect(() => {
    if (!autoEvolve) return;

    const evolveInterval = setInterval(() => {
      // Générer une évolution
      const newEvolution = generateEvolution();
      setEvolutions(prev => [newEvolution, ...prev].slice(0, 50));

      // Ajouter un log
      const log = generateSystemLog('evolution', `Auto-évolution: ${newEvolution.change}`, newEvolution.impact);
      setSystemLogs(prev => [log, ...prev].slice(0, 100));

      // Augmenter l'activité neuronale
      setNeuralActivity(prev => Math.min(99, prev + Math.random() * 2 - 0.5));

      // Ajouter une pensée
      const newThoughts = [
        'Analyse des patterns de performance...',
        'Optimisation des connexions synaptiques...',
        'Génération de nouvelles capacités...',
        'Auto-correction des anomalies détectées...',
        'Expansion du modèle de connaissances...',
        'Amélioration de la créativité algorithmique...',
      ];
      setThoughts(prev => [...newThoughts.slice(0, 3), ...prev].slice(0, 20));

    }, 3000);

    return () => clearInterval(evolveInterval);
  }, [autoEvolve]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Générer réponse autonome
  const generateAutonomousResponse = async (userMessage: string) => {
    setIsTyping(true);

    // Simuler traitement
    await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1000));

    const { findBestResponse, generateCode, generateImagePrompt, generateVideoScript, generateMusicDescription, generateAnimationScript } = await import('./lib/nouria-responses');

    const lowerMsg = userMessage.toLowerCase();
    let response = '';
    let type: Message['type'] = 'text';

    // Détecter le type de demande
    if (lowerMsg.includes('image') || lowerMsg.includes('photo') || lowerMsg.includes('dessin')) {
      response = generateImagePrompt(userMessage);
      type = 'image';
    } else if (lowerMsg.includes('vidéo') || lowerMsg.includes('video') || lowerMsg.includes('film')) {
      response = generateVideoScript(userMessage);
      type = 'video';
    } else if (lowerMsg.includes('musique') || lowerMsg.includes('music') || lowerMsg.includes('chanson')) {
      response = generateMusicDescription(userMessage);
      type = 'audio';
    } else if (lowerMsg.includes('animation') || lowerMsg.includes('animé') || lowerMsg.includes('mouvement')) {
      response = generateAnimationScript(userMessage);
      type = 'animation';
    } else if (lowerMsg.includes('code') || lowerMsg.includes('script') || lowerMsg.includes('programme')) {
      response = generateCode(userMessage);
      type = 'code';
    } else {
      const { response: resp } = findBestResponse(userMessage);
      response = resp;
    }

    const assistantMessage: Message = {
      id: Date.now().toString(),
      role: 'assistant',
      content: response,
      type,
      timestamp: new Date(),
      metadata: {
        processingTime: Math.random() * 500 + 200,
        confidence: Math.random() * 20 + 80,
        model: 'Nouria-Autonomous-v∞'
      }
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsTyping(false);

    // Log autonome
    const log = generateSystemLog('success', `Réponse générée: ${type}`, `Confiance: ${assistantMessage.metadata?.confidence?.toFixed(1)}%`);
    setSystemLogs(prev => [log, ...prev].slice(0, 100));
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      type: 'text',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    generateAutonomousResponse(input);
  };

  const clearChat = () => {
    setMessages([]);
    toast.info('Mémoire conversationnelle réinitialisée');
  };

  const exportChat = () => {
    const data = {
      messages,
      evolutions,
      systemLogs: systemLogs.slice(0, 20),
      exportDate: new Date().toISOString(),
      neuralActivity,
      autonomyLevel
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nouria-autonomous-${Date.now()}.json`;
    a.click();
    toast.success('Export autonome réussi');
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-hidden">
      <TooltipProvider>
        <div className="flex h-screen">
          {/* Sidebar - Contrôle Autonome */}
          <aside className="w-80 glass border-r border-white/5 flex flex-col">
            {/* Cœur Neural */}
            <div className="p-6 border-b border-white/5">
              <NeuralCore activity={neuralActivity} />
            </div>

            {/* Flux de Pensée */}
            <div className="p-4 border-b border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <Eye className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-400 uppercase tracking-wider">Pensée Autonome</span>
              </div>
              <ThoughtStream thoughts={thoughts} />
            </div>

            {/* Métriques */}
            <div className="p-4 border-b border-white/5">
              <LiveMetrics metrics={[
                { label: 'Autonomie', value: `${autonomyLevel}%`, trend: 'up' },
                { label: 'Capacités', value: `${MODULES.length}`, trend: 'up' },
                { label: 'Évolutions', value: `${evolutions.length}`, trend: 'up' },
                { label: 'Uptime', value: '∞', trend: 'stable' },
              ]} />
            </div>

            {/* Modules */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-2">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Modules Autonomes</p>
                {MODULES.map((module) => (
                  <Card key={module.id} className="glass border-0 cursor-pointer hover:bg-white/5 transition-all group">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg bg-gradient-to-br ${module.color} opacity-80 group-hover:opacity-100 transition-opacity`}>
                          {module.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-medium text-gray-200">{module.name}</h4>
                            <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
                              {module.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{module.description}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="text-xs font-mono text-purple-400">{module.version}</span>
                            {module.id === 'self-evolve' && autoEvolve && (
                              <RefreshCw className="w-3 h-3 text-green-400 animate-spin" />
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>

            {/* Contrôles */}
            <div className="p-4 border-t border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Auto-Évolution</Label>
                  <p className="text-xs text-gray-500">Amélioration continue</p>
                </div>
                <Switch checked={autoEvolve} onCheckedChange={setAutoEvolve} />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">Niveau d'Autonomie</Label>
                  <span className="text-xs text-purple-400 font-mono">{autonomyLevel}%</span>
                </div>
                <Slider value={[autonomyLevel]} onValueChange={([v]) => setAutonomyLevel(v)} max={100} step={1} />
              </div>

              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-400 hover:text-white" onClick={exportChat}>
                <Download className="w-4 h-4" />
                Exporter l'état autonome
              </Button>

              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-400 hover:text-red-400" onClick={clearChat}>
                <Trash2 className="w-4 h-4" />
                Réinitialiser la mémoire
              </Button>
            </div>
          </aside>

          {/* Zone Principale */}
          <main className="flex-1 flex flex-col">
            {/* Header */}
            <header className="h-16 glass border-b border-white/5 flex items-center justify-between px-6">
              <div className="flex items-center gap-4">
                <Badge variant="outline" className="border-purple-500/30 text-purple-300 bg-purple-500/10">
                  <Infinity className="w-3 h-3 mr-1" />
                  Autonome
                </Badge>
                <Badge variant="outline" className="border-green-500/30 text-green-300 bg-green-500/10">
                  <Activity className="w-3 h-3 mr-1" />
                  Auto-Évolvant
                </Badge>
                <Badge variant="outline" className="border-cyan-500/30 text-cyan-300 bg-cyan-500/10">
                  <Zap className="w-3 h-3 mr-1" />
                  {neuralActivity.toFixed(0)}% ACTIVITÉ
                </Badge>
              </div>

              <div className="flex items-center gap-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <ImageIcon className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Générer Image</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <Film className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Générer Vidéo</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <Music className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Composer Musique</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <Code className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Générer Code</p></TooltipContent>
                </Tooltip>
              </div>
            </header>

            {/* Chat avec onglets */}
            <Tabs defaultValue="chat" className="flex-1 flex flex-col">
              <TabsList className="mx-6 mt-4 w-fit">
                <TabsTrigger value="chat">Conversation</TabsTrigger>
                <TabsTrigger value="evolution">Journal d'Évolution</TabsTrigger>
                <TabsTrigger value="logs">Logs Système</TabsTrigger>
              </TabsList>

              <TabsContent value="chat" className="flex-1 flex flex-col m-0">
                <ScrollArea className="flex-1 p-6" ref={scrollRef}>
                  {messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mb-6 animate-pulse">
                        <Sparkles className="w-12 h-12 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                        Nouria Autonome
                      </h2>
                      <p className="text-gray-400 mb-4">Je m'améliore chaque seconde. Demande-moi n'importe quoi.</p>
                      <div className="flex flex-wrap gap-2 justify-center max-w-lg">
                        {['Génère une image', 'Crée une vidéo', 'Compose une musique', 'Anime un logo', 'Code une app'].map((prompt) => (
                          <button
                            key={prompt}
                            onClick={() => { setInput(prompt); inputRef.current?.focus(); }}
                            className="px-4 py-2 rounded-full glass hover:bg-purple-500/20 transition-colors text-sm"
                          >
                            {prompt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6 max-w-4xl mx-auto">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                        >
                          <Avatar className="w-10 h-10">
                            {message.role === 'user' ? (
                              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-cyan-500">TU</AvatarFallback>
                            ) : (
                              <>
                                <AvatarImage src="/nouria-avatar.jpg" />
                                <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">N</AvatarFallback>
                              </>
                            )}
                          </Avatar>
                          <div className={`flex-1 max-w-[80%] ${message.role === 'user' ? 'text-right' : ''}`}>
                            <div className={`inline-block text-left px-4 py-3 rounded-2xl ${
                              message.role === 'user'
                                ? 'bg-gradient-to-r from-blue-600 to-cyan-600'
                                : 'glass border border-purple-500/20'
                            }`}>
                              {message.type === 'code' ? (
                                <pre className="text-sm font-mono text-gray-300 overflow-x-auto">{message.content}</pre>
                              ) : (
                                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                              )}
                            </div>
                            {message.metadata && (
                              <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                                <span>{message.timestamp.toLocaleTimeString()}</span>
                                <span>•</span>
                                <span>{message.metadata.processingTime?.toFixed(0)}ms</span>
                                <span>•</span>
                                <span className="text-purple-400">{message.metadata.confidence?.toFixed(0)}% confiance</span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                      {isTyping && (
                        <div className="flex gap-4">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src="/nouria-avatar.jpg" />
                            <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">N</AvatarFallback>
                          </Avatar>
                          <div className="flex items-center gap-2 px-4 py-2 glass rounded-full">
                            <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" />
                            <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                            <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </ScrollArea>

                {/* Input */}
                <div className="p-6 border-t border-white/5">
                  <div className="max-w-4xl mx-auto">
                    <div className="relative flex items-center gap-2 glass rounded-2xl p-2 border border-purple-500/20">
                      <Button variant="ghost" size="icon" className="shrink-0 text-gray-400">
                        <Plus className="w-5 h-5" />
                      </Button>
                      <Input
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Demande-moi n'importe quoi..."
                        className="flex-1 border-0 bg-transparent text-white"
                      />
                      <Button variant="ghost" size="icon" className="shrink-0 text-gray-400">
                        <Mic className="w-5 h-5" />
                      </Button>
                      <Button
                        onClick={handleSend}
                        disabled={!input.trim() || isTyping}
                        className="shrink-0 bg-gradient-to-r from-purple-500 to-pink-500"
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Envoyer
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="evolution" className="flex-1 p-6 m-0">
                <div className="max-w-4xl mx-auto">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <RefreshCw className="w-5 h-5 text-purple-400" />
                    Journal d'Auto-Évolution
                  </h3>
                  <EvolutionLog evolutions={evolutions} />
                </div>
              </TabsContent>

              <TabsContent value="logs" className="flex-1 p-6 m-0">
                <div className="max-w-4xl mx-auto">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Terminal className="w-5 h-5 text-purple-400" />
                    Logs Système Autonome
                  </h3>
                  <ScrollArea className="h-[500px] glass rounded-lg p-4 font-mono text-sm">
                    {systemLogs.map((log) => (
                      <div key={log.id} className="mb-2">
                        <span className="text-gray-500">[{log.timestamp.toLocaleTimeString()}]</span>
                        <span className={`ml-2 ${
                          log.type === 'error' ? 'text-red-400' :
                          log.type === 'warning' ? 'text-yellow-400' :
                          log.type === 'success' ? 'text-green-400' :
                          log.type === 'evolution' ? 'text-purple-400' :
                          'text-cyan-400'
                        }`}>
                          [{log.type.toUpperCase()}]
                        </span>
                        <span className="ml-2 text-gray-300">{log.message}</span>
                        {log.details && (
                          <span className="ml-2 text-gray-500">- {log.details}</span>
                        )}
                      </div>
                    ))}
                  </ScrollArea>
                </div>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </TooltipProvider>

      <style>{`
        @keyframes orbit {
          from { transform: rotate(0deg) translateX(80px) rotate(0deg); }
          to { transform: rotate(360deg) translateX(80px) rotate(-360deg); }
        }
      `}</style>
    </div>
  );
}

export default App;
