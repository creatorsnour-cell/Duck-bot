# Nouria AI

Une interface de chat IA moderne et élégante construite avec React, TypeScript et Tailwind CSS.

## 🚀 Fonctionnalités

- 💬 Interface de chat en temps réel
- 💻 Génération de code avec syntax highlighting
- 🎨 Design futuriste avec animations
- 🎤 Support vocal (préparation)
- 🖼️ Génération d'images (préparation)
- ⚙️ Paramètres personnalisables
- 📤 Export des conversations

## 🛠️ Technologies

- React 18
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- Lucide React

## 📦 Installation

```bash
npm install
npm run dev
```

## 🏗️ Build

```bash
npm run build
```

## 🌐 Déploiement

Le dossier `dist/` contient l'application buildée prête pour le déploiement.

## 📝 License

MIT
